#ifndef __RANDOM
#define __RANDOM

float random(int max);


#endif // __RANDOM
